from unicodedata import name
from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('', views.home),
    path('home', views.index , name="index"),
    path('request', views.areq, name="request"),
    path('ad', views.ad, name="ad"),
    path('userreq/<int:id>', views.userreq, name="userreq"),
    path('updaterecord/<int:id>',views.updaterecord, name='updaterecord'),
    path('update/<int:id>',views.update, name='update'),
    path('displayusers', views.duser, name="displayusers"),
    path('user/<int:id>', views.user, name="user"),
    path('new/<int:id>', views.new, name='new'),
    path('login', views.login, name="login"),
    path('signup', views.signup, name="signup"),
]
