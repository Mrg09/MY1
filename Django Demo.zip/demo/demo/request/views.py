import re
from django.shortcuts import redirect,render
from django.http import HttpResponse
from django.contrib import messages
from .models import person,form


def home(request):
    return redirect('index')

def index(request):
    return render(request, 'index.html')    

def areq(request):
    f=form.objects.all()
    return render(request, 'request.html', {"requests":f})
    
def ad(request):
    return render(request,'admin.html')

def duser(request):
    user=person.objects.filter(admin=0)
    return render(request, 'displayusers.html', {'users':user})

def update(request, id):
    req = form.objects.filter(fid=id).values()[0]
    return render(request, 'update.html', {'form':req})

def updaterecord(request, id):
    if request.method == 'POST':
        reason = request.POST.get('reason',False)
        accept = request.POST.get('status',False)
        nform = form.objects.get(fid=id)
        nform.accept = accept
        nform.reason = reason
        nform.status = True
        nform.save()
    return redirect('request')

def user(request, id):
    u = person.objects.filter(id=id)
    return render(request, 'user.html',{'user':u, 'id':id})

def userreq(request, id):
    f = form.objects.filter(uid=id)
    return render(request,'userreq.html', {'requests':f, 'id':id})

def new(request, id):
    if request.method == 'POST':
        u = person.objects.filter(id=id)
        reqn = request.POST['type']
        disc = request.POST['disc']
        req = form.objects.create(uid=id, rname=reqn, disc=disc, status=False, accept=False)
        req.save()
        return render(request, 'user.html', {'user':u, 'id':id})
    else:
        u = person.objects.filter(id=id)
        return render(request,'new.html',{'user':u, 'id':id})
    
def login(request):
    if request.method == 'POST':
        email = request.POST['email']
        passw = request.POST['password']
        if person.objects.filter(email=email).exists():
            user=person.objects.filter(email=email).values()[0]
            print(user)
            if user["password"]==passw:
                if user["admin"]==True:
                    u=person.objects.all()
                    return render(request,'admin.html',{'users':u, 'id':user['id']})
                else:
                    u=person.objects.get(id=user['id'])
                    return render(request,'user.html', {'users':u, 'id':user['id']})
            else:
                messages.info(request,'Wrong Password')
                return redirect('login')
        else:
            messages.info(request,'Email does not exists please sign up')
            return redirect('signup')

    else:
        return render(request, 'login.html',)

def signup(request):
    if request.method == 'POST':
        name = request.POST['name']
        pnumber = request.POST['pnumber']
        email = request.POST['email']
        password1 = request.POST['password1']
        password2 = request.POST['password2']
        
        if password1==password2:
            if person.objects.filter(email=email).exists():
                messages.info(request,'Email taken')
                return redirect('signup')
            else:
                user = person.objects.create(name=name,pnumber=pnumber,email=email,password=password1,admin=False)
                user.save()
                messages.info(request,'user created')
                return redirect('login')
        else:
            messages.info(request,'Password doesnot match')
            return redirect('signup')
            
    else:
        return render(request, 'signup.html') 