from distutils.command.upload import upload
import email
from django.db import models
from django.contrib.auth.models import User
  
#Create your models here.
class person(models.Model ):
    id = models.AutoField(primary_key=True, auto_created=True)
    name = models.CharField(max_length=40)
    pnumber = models.BigIntegerField()
    admin = models.BooleanField(False)
    email = models.EmailField(max_length=100)
    password = models.CharField(max_length=100)
    
    def __str__(self):
        return self.name
    
class form(models.Model):
    fid = models.AutoField(primary_key=True, auto_created=True)
    uid = models.IntegerField()
    rname = models.CharField(max_length=50)
    disc = models.CharField(max_length=1000)
    status = models.BooleanField(False)
    accept = models.BooleanField(False)
    reason = models.CharField(max_length=500)

    def __str__(self):
        return self.rname
