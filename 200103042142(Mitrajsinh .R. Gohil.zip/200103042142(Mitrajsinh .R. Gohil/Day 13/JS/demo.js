function ExternalAlert()
        {
            alert("External alert");
        }
        function ExternalConfirm()
        {
            if(confirm("External confirm??"))
            {
                alert("yesss");

            }else
            {
                alert("Noooo");
            }
        }
        function ExternalPrompt()
        {
           var name = prompt("Enter External prompt value");

           alert("Hii "+ name);
        }