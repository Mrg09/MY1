# INVENTORY MANAGEMENT
import os
import sys
import sqlite3
import games
import datetime
import purchase
import product
import sales
import database
import user
import billing


def AIM(uid,upass):
    now = datetime.datetime.now()   #saving current date and time


    def clrscr():
        print("\n\t\t\t\t\t"*10)

    while True:
        clrscr()
        print("\t\t\t\t\t\t\t STOCK MANAGEMENT")  #Displaying a menu containing of all the options avilable to administrator
        print("\t\t\t\t\t\t\t ****************\n")
        print("\t\t\t\t\t\t 1. PRODUCT MANAGEMENT")
        print("\t\t\t\t\t\t 2. PURCHASE MANAGEMENT")
        print("\t\t\t\t\t\t 3. SALES MANAGEMENT")
        print("\t\t\t\t\t\t 4. USER MANAGEMENT")
        print("\t\t\t\t\t\t 5. DATABASE SETUP")
        print("\t\t\t\t\t\t 6. Play Game")
        print("\t\t\t\t\t\t 7. EXIT\n")

        n = int(input("\t\t\t\t\t-->Enter your choice :"))
        if n == 1:
            product.product_mgmt()
        if n == 2:
            os.system('cls')
            purchase.purchase_mgmt()
        if n == 3:
            sales.sales_mgmt()
        if n == 4:
            user.user_mgmt()
        if n == 5:
            database.db_mgmt()
        if n == 6:
            gmains(uid,upass)
        if n == 7:
            print("\t\t\t\t\t    ***THANK YOU***")
            print('\t\t\t\t\t    """""""""""""""')
            sys.exit()

            
def GIM(uid,upass):
    now = datetime.datetime.now()   #saving current date and time


    def clrscr():
        print("\n\t\t\t\t\t"*10)

    while True:
        clrscr()
        print("\t\t\t\t\t\t\t STOCK MANAGEMENT")   #Displaying a menu containing of all the options avilable to guest
        print("\t\t\t\t\t\t\t ****************\n")
        print("\t\t\t\t\t\t 1. PRODUCT MANAGEMENT")
        print("\t\t\t\t\t\t 2. SALES MANAGEMENT")
        print("\t\t\t\t\t\t 3. Play Game")
        print("\t\t\t\t\t\t 4. EXIT\n")
        n = int(input("\t\t\t\t\t-->Enter your choice :"))
        if n == 1:
            product.product_mgmt()
        if n == 2:
            sales.sales_mgmt()
        if n == 3:
            gmains(uid,upass)
        if n == 4:
            print("\t\t\t\t\t    ***THANK YOU***")
            print('\t\t\t\t\t    """""""""""""""')
            sys.exit()
def main():
    print("\t\t\t\t\t\t***WELCOME***") #Displaying main menu
    print('\t\t\t\t\t\t"""""""""""""')
    print("\n\t\t\t\t\t1.START,")
    print("\n\t\t\t\t\t2.EXIT")
    mydb = sqlite3.connect('TEST.db')
    mycursor = mydb.cursor()
    sql = "SELECT COUNT(*) FROM USERS ;"
    my1=mycursor.execute(sql)
    for i in my1:
        ln=i[0]
    ch=int(input("Enter your choice:-"))
    if ch==1:
        ch2=int(input("\t\t\t\t\t1.Log in, \n\t\t\t\t\t2.Sign up\n\t\t\t\t\tEnter your choice:-"))
        if ch2==1:
            cn=0
            uid=input("\n\t\t\t\t\tEnter User ID:-")  #takin user id and password as input
            upass=input("\t\t\t\t\tEnter Password:-") 
            login(uid,upass,ln)
        if ch==2:
            user.add_user()
            main()
    elif ch==2:
        print("\t\t\t\t\t    ***THANK YOU***")
        print('\t\t\t\t\t    """""""""""""""')
        sys.exit()

    else:
        print("You have enterd wrong choice try again!")

def login(uid,upass,ln):
    cn=0
    mydb = sqlite3.connect('TEST.db')
    mycursor = mydb.cursor()
    sql = "SELECT uid,upass,utype FROM USERS ;"
    my1=mycursor.execute(sql)
    l1=[]
    for i in my1:
        l1.append(i)
    for i in range(0,len(l1)):   #cheking whether entered is exist or not 
        if l1[i][0]==uid:        #If exist password entered is correct or not
            if l1[i][1]==upass:  #If correct then user in Administrator or guest
                if l1[i][2]=="Administrator":
                    AIM(uid,upass)        #calling administrator's function
                elif l1[i][2]=="Guest":
                    GIM(uid,upass)        #calling guest's function
                else:
                    continue
            else:
                print("YOU HAVE ENTERED WRONG PASSWORD TRY AGAIN!")
                main()
        else:
            cn+=1
            if cn==ln:
                print("User does not exist.....")
                main()
            continue
def gmains(uid1,upass1):
    print("1.Tic Tac Toe('X' and 'O'),")
    print("2.Hangman Game(Guess the word),")
    print("3.Back.")
    uid=uid1
    upass=upass1
    ch=int(input("Enter your choice:-"))
    if ch==1:
        games.TicTac(uid,upass)
        
    elif ch==2:
        games.Hang(uid,upass)
        
    elif ch==3:
        login(uid,upass)

main()  #calling main function
