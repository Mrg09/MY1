#PRODUCT MODULE
import os
import sqlite3
import datetime
now = datetime.datetime.now()   #saving current date and time
def clrscr():
    print("\n\t\t\t\t\t"*10)
def product_mgmt():  #Function for the management of products with options of updating,listing all available products and adding new product
    while True:
        print("\n\n\t\t\t\t\t\t\t 1. Add New Product")
        print("\t\t\t\t\t\t\t 2. List Product")
        print("\t\t\t\t\t\t\t 3. Update Product")
        print("\t\t\t\t\t\t\t 4. Delete Product")
        print("\t\t\t\t\t\t\t 5. Back (Main Menu)")
        p = int(input("\n\n\t\t\t\t\t-->Enter Your Choice :"))
        if p == 1:
            add_product()
        if p == 2:
            search_product()
        if p == 3:
            update_product()
        if p == 4:
            delete_product()
        if p == 5:
            break

def add_product():   #Funtion to add product into product table
    cnt=[]
    mydb = sqlite3.connect('TEST.db')
    mycursor = mydb.cursor()
    code = int(input("\t\t\t\t\t\t -->Enter product code :"))
    search = "SELECT * FROM PRODUCTS WHERE pcode="+str(code)+";"
    my1=mycursor.execute(search)
    for x in my1:
        cnt.append(x[0])
    if len(cnt) == 0:
        name = input("\t\t\t\t\t\t -->Enter product name :")
        qty = int(input("\t\t\t\t\t\t -->Enter product quantity :"))
        price = float(input("\t\t\t\t\t\t -->Enter product unit price :"))
        cat = input("\t\t\t\t\t\t -->Enter Product category :")
        val = (code,name,price,qty,cat)
        sql = "INSERT INTO PRODUCTS values("+ str(code) +","+"'"+ name +"'"+","+str(price)+","+str(qty)+","+"'"+cat+"'"+");"
        mycursor.execute(sql)
        mydb.commit()
        product_mgmt()
    else:
        print("\n\t\t\t\t\t\t\t ***Product already exist***")
        product_mgmt()


def update_product():   #Funtion is used to update any current product details
    mydb = sqlite3.connect('TEST.db')
    mycursor = mydb.cursor()
    code = int(input("\t\t\t\t\t -->Enter the product code :"))
    qty = int(input("\t\t\t\t\t -->Enter the newly arrived stock quantity :"))
    sql = "UPDATE PRODUCTS SET pqty=pqty+"+str(qty)+" WHERE pcode="+str(code)+";"
    mycursor.execute(sql)
    mydb.commit()
    print("\t\t\t\t\t\t\t ***Product details updated***")


def delete_product():   #Function is used to delete any product from the product table
    mydb = sqlite3.connect('TEST.db')
    mycursor=mydb.cursor()
    code = int(input("\t\t\t\t\t\t -->Enter the product code :"))
    sql = "DELETE FROM PRODUCTS WHERE pcode = '"+str(code)+"';"
    mycursor.execute(sql)
    mydb.commit()
    print("\t\t\t\t\t",mycursor.rowcount,"***record(s) deleted***")


def search_product():   #Function is used to search for a product in product table
    while True:
        print("\t\t\t\t\t\t\t 1. List all product")
        print("\t\t\t\t\t\t\t 2. List product code wise")
        print("\t\t\t\t\t\t\t 3. List product category wise")
        print("\t\t\t\t\t\t\t 4. Back (Main Menu)")
        s = int(input("\t\t\t\t\t\t -->Enter Your Choice :"))
        if s == 1:
            list_product()
        if s == 2:
            code=int(input("\n\t\t\t\t\t\t -->Enter product code :"))
            list_prcode(code)
        if s == 3:
            list_prcat()
        if s == 4:
            break

def list_product():   #Funtion is used to list all the product of product table
    mydb = sqlite3.connect('TEST.db')
    mycursor = mydb.cursor()
    sql = "SELECT * from PRODUCTS;"
    my1=mycursor.execute(sql)
    print("\t\t\t\t\t\t\t *PRODUCT DETAILS*")
    print("\t\t\t\t\t\t\t !~~~~~~~~~~~~~~~!")
    print(" "*15,"-" * 102)
    print("\t\t| code   |\t\t name"," "*28,"|   price    |  quantity |    category    |")
    print(" "*15,"-" * 102)
    for i in my1:
        print("\t\t|", i[0]," "*(5-len(str(i[0]))),"| ", i[1], " "*(45-len(str(i[1]))),"| ", i[2], " "*(8-len(str(i[2]))),"|    ", i[3], " "*(4-len(str(i[3]))),"|  ", i[4]," "*(11-len(str(i[4]))),"|")
    print(" "*15,"-" * 102)
    print("\n\n")

    
def list_prcode(code):
    mydb = sqlite3.connect('TEST.db')
    mycursor = mydb.cursor()
    sql = "SELECT * from PRODUCTS WHERE pcode="+str(code)+";"
    my1=mycursor.execute(sql)
    print("\n\n")
    print("\t\t\t\t\t\t\t\t *PRODUCT DETAILS*")
    print("\t\t\t\t\t\t\t\t !~~~~~~~~~~~~~~~!")
    print(" "*15,"-" * 102)
    print("\t\t| code   |\t\t name"," "*28,"|   price    |  quantity |    category    |")
    print(" "*15,"-" * 102)
    for i in my1:
        print("\t\t|", i[0]," "*(5-len(str(i[0]))),"| ", i[1], " "*(45-len(str(i[1]))),"| ", i[2], " "*(8-len(str(i[2]))),"|    ", i[3], " "*(4-len(str(i[3]))),"|  ", i[4]," "*(11-len(str(i[4]))),"|")
    print(" "*15,"-" * 102)
    print("\n\n")

def list_prcat():
    mydb = sqlite3.connect('TEST.db')
    mycursor = mydb.cursor()
    cat = input("\t\t\t\t\t\t -->Enter Product category :")
    sql="SELECT * from PRODUCTS WHERE pcat ='"+str(cat)+"';"
    my1=mycursor.execute(sql)
    print("\n\n")
    print("\t\t\t\t\t\t\t *PRODUCT DETAILS*")
    print("\t\t\t\t\t\t\t !~~~~~~~~~~~~~~~!")
    print(" "*15,"-" * 102)
    print("\t\t| code   |\t\t name"," "*28,"|   price    |  quantity |    category    |")
    print(" "*15,"-" * 102)
    for i in my1:
        print("\t\t|", i[0]," "*(5-len(str(i[0]))),"| ", i[1], " "*(45-len(str(i[1]))),"| ", i[2], " "*(8-len(str(i[2]))),"|    ", i[3], " "*(4-len(str(i[3]))),"|  ", i[4]," "*(11-len(str(i[4]))),"|")
    print(" "*15,"-" * 102)
    print("\n\n")
