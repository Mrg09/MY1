import sqlite3
mydb = sqlite3.connect('TEST.db')
mycursor = mydb.cursor()
sql = "SELECT * FROM USERS;"
my1=mycursor.execute(sql)   
print("\t\t\t\t\t\t\t USER DETAILS")
print("\t\t\t\t  ", "-" * 64)
print("\t\t\t\t   |                UID"," "*18,"|       name \t  |")
print("\t\t\t\t  ", "-" * 64)
for i in my1:
    print("\t\t\t\t   |", i[0]," "*(36-(len(i[0]))),"|", i[1]," "*(19-len(i[1])),"|",i[2])
print("\t\t\t\t  ", "-" * 64)
