#SALES MODULE
import os
import sqlite3
import billing
import datetime
now = datetime.datetime.now()   #saving current date and time

def sales_mgmt( ):  #Function for sales management showing all sold items and billing is also in it
    while True:
        print("\t\t\t\t\t\t\t 1. Sale Items")
        print("\t\t\t\t\t\t\t 2. List Sales")
        print("\t\t\t\t\t\t\t 3. Back (Main Menu)")
        s = int (input("\t\t\t\t\t\t -->Enter Your Choice :"))
        if s == 1:
            sale_product()
        if s == 2:
            list_sale()
        if s == 3:
            break


def sale_product():
    x=int(input("\t\t\t\t\t\t1.Add product into list\n\t\t\t\t\t\t2.Remove item from list\n\t\t\t\t\t\t3.check out\n\t\t\t\t\t\t4.exit\n\t\t\t\t\t=>Enter your choice:-"))
    if x==1:
        billing.add_product()
    elif x==2:
        billing.remove_item()
    elif x==3:
        billing.check_out()
    elif x==4:
        sales_mgmt()
    else:
        print("You have entered wrong choice try again...")
        sale_product()

def list_sale():
    mydb = sqlite3.connect('TEST.db')
    mycursor = mydb.cursor()
    sql = "SELECT * FROM SALES;"
    my1=mycursor.execute(sql)
    print("\t\t\t\t\t\t\t SALES DETAILS")
    print(" "*27,"-" * 78)
    print("\t\t\t    |\t        Date"," "*8,"| Product_Code |  Price    | Quantity |   Total    |")
    print(" "*27,"-" * 78)
    for x in my1:
        m=list(x[0])
        n=''
        for i in range(0,19):
            n=n+str(m[i])
        print("\t\t\t    |  ",n, "  |    ", x[1]," "*(7-len(str(x[1]))), "| ", x[2]," "*(7-len(str(x[2]))), "|   ", x[3]," "*(4-len(str(x[3]))), "| ", x[4]," "*(8-len(str(x[4]))),"|")
    print(" "*27,"-" * 78)
    sq2 = "SELECT SUM(Total) FROM SALES;"
    my1=mycursor.execute(sq2)
    for a in my1:
        a=list(a)
        print(" "*27,"| TOTAL SALE:-",a[0]," "*(60-len(str(a[0]))),"|")
    print(" "*27,"-" * 78)


    
