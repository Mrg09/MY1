#PURCHASE MODULE
import os
import sqlite3
import datetime
now = datetime.datetime.now()   #saving current date and time

def purchase_mgmt():  #Function for management of purchases too be done it includes adding product in list and showing list1
    while True:
        print("\t\t\t\t\t\t\t\t 1. Add Order")
        print("\t\t\t\t\t\t\t\t 2. List Order")
        print("\t\t\t\t\t\t\t\t 3. Back (Main Menu)")
        o = int(input("\t\t\t\t\t\t\t -->Enter Your Choice :"))
        if o == 1:
            add_order()
        if o == 2:
            list_order()
        if o == 3:
            break


def add_order():  #Function which is used to add orders in the order table
    mydb = sqlite3.connect('TEST.db')
    mycursor = mydb.cursor()
    now = datetime.datetime.now()
    code = int(input("\t\t\t\t\t -->Enter product code :"))
    oid = now.year+now.month+now.day+now.hour+now.minute+now.second
    qty = int(input("\t\t\t\t\t -->Enter product quantity : "))
    price = float(input("\t\t\t\t\t -->Enter Product unit price: "))
    cat = input("\t\t\t\t\t -->Enter product category: ")
    sup = input("\t\t\t\t\t -->Enter Supplier details: ")
    sql = "INSERT INTO ORDERS values ("+ str(oid) +",'"+ str(now) +"','"+ str(code) +"',"+ str(price) +","+ str(qty) +",'"+ cat +"');"
    mycursor.execute(sql)
    mydb.commit()


def list_order():  #Function which list all elements in order table
    mydb = sqlite3.connect('TEST.db')
    mycursor = mydb.cursor()
    sql = "SELECT * from orders;"
    my1=mycursor.execute(sql)
    print("\t\t\t\t\t\t ORDER DETAILS")
    print((" "*21),("-"*90))
    print("\t\t      | orderid |\t      date"," "*11,"| productcode |   price    | quantity |  category  |")
    print((" "*21),("-"*90))
    for i in my1:
        print("\t\t      | ",i[0], " "*(5-len(str(i[0]))),"| ", i[1]," "*(26-len(str(i[1]))), "|   ", i[2]," "*(7-len(str(i[2]))),"| ",i[3], " "*(8-len(str(i[3]))),"|   ", i[4], " "*(4-len(str(i[4]))),"| ", i[5]," "*(8-len(str(i[5]))),"|")
    print((" "*21),("-"*90))                                                                                                                                        
