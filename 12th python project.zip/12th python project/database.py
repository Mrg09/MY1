#DATABASE MODULE
import os
import sqlite3
import datetime
now = datetime.datetime.now()   #saving current date and time


def db_mgmt( ):  #Database management function
    while True:
        print("\t\t\t\t\t\t\t\t 1. Database creation")
        print("\t\t\t\t\t\t\t\t 2. List Database")
        print("\t\t\t\t\t\t\t\t 3. Back (Main Menu)")
        p = int(input("\t\t\t\t\t\t\t -->Enter Your Choice :"))
        if p == 1:
            create_database()
        if p == 2:
            list_database()
        if p == 3:
            break

def create_database():  #Function to create whole database
    mydb = sqlite3.connect('TEST.db')
    mycursor = mydb.cursor()
    print(" Creating PRODUCT table")
    sql = "CREATE TABLE if not exists PRODUCTS(pcode int(10) PRIMARY KEY,pname char(30) NOT NULL,price float(8,2),pqty int(4),pcat char(30));"
    mycursor.execute(sql)
    print("PRODUCT tsble created")
    print("Creating ORDER table")
    sql2 = "CREATE TABLE if not exists ORDERS(orderid int(10)PRIMARY KEY, orderdate DATE, pcode char(30) NOT NULL , pprice float(8,2), pqty int(4), pcat char(30));"
    mycursor.execute(sql2)
    print("ORDER table created")
    print("Creating SALES table")
    sql = "CREATE TABLE if not exists SALES(salesdate DATE, pcode char(30) references product(pcode), pprice float(8,2), pqty int(4), Total double(8,2));"
    mycursor.execute(sql)
    print("SALES table created")
    print("Creating USER table")
    sql = "CREATE TABLE if not exists USERS(uid varchar(30) NOT NULL, uname varchar(30),upass varchar(30),utype varchar(15));"
    mycursor.execute(sql)
    print("USER table created")
    print("Creating BILLING table")
    sq2="CREATE TABLE if not exists BILLING(Billdate DATE, pcode char(30) references product(pcode), pprice float(8,2), pqty int(4), Total double(8,2));"
    my2=mycursor.execute(sq2)
    print("BILLING table created")
create_database()

def list_database():  #Function which lists all tables from database
    mydb = sqlite3.connect('TEST.db')
    mycursor = mydb.cursor()
    sql = "SELECT name FROM sqlite_master WHERE type='table';"
    my1=mycursor.execute(sql)
    for i in my1:
        print(i)
