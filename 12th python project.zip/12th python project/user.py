#USER MODULE
import os
import sqlite3
import datetime
now = datetime.datetime.now()   #saving current date and time

def user_mgmt():  #Function for management of users details like userid(ex:-email) and name
    while True:
        print("\t\t\t\t\t\t\t\t 1. Add user")
        print("\t\t\t\t\t\t\t\t 2. List user")
        print("\t\t\t\t\t\t\t\t 3. Back (Main Menu)")
        u = int(input("\t\t\t\t\t\t\t -->Enter Your Choice :"))
        if u == 1:
            add_user()
        if u == 2:
            list_user()
        if u == 3:
            break

def add_user():
    mydb = sqlite3.connect('TEST.db')
    mycursor = mydb.cursor()
    uid = input("\t\t\t\t\t -->Enter emaid id :")
    name = input("\t\t\t\t\t -->Enter Name :")
    password = input("\t\t\t\t\t -->Enter Password :")
    utype = input("\t\t\t\t\t -->Enter user type:-")
    sql = "INSERT INTO USERS values ('"+str(uid)+"','"+name+"','"+password+"','"+utype+"');"
    mycursor.execute(sql)
    mydb.commit()
    print(mycursor.rowcount, "\t\t\t\t\t***user created***")


def list_user():
    mydb = sqlite3.connect('TEST.db')
    mycursor = mydb.cursor()
    sql = "SELECT uid, uname from USERS;"
    my1=mycursor.execute(sql)
    clrscr()
    print("\t\t\t\t\t\t\t USER DETAILS")
    print("\t\t\t\t  ", "-" * 64)
    print("\t\t\t\t   |                UID"," "*18,"|       name \t  |")
    print("\t\t\t\t  ", "-" * 64)
    for i in my1:
        print("\t\t\t\t   |", i[0]," "*(36-(len(i[0]))),"|", i[1]," "*(19-len(i[1])),"|")
    print("\t\t\t\t  ", "-" * 64)


def clrscr():
    print("\n\t\t\t\t\t"*10)




    
