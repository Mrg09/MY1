from __future__ import print_function
import time
import random
import sys
import IMmodule


def TicTac(uid,upass):
    #tictactoe game for 2 players
    choices = []    
    cn=0
    for x in range (0, 9) :
        choices.append(str(x + 1))

    playerOneTurn = True
    winner = False

    while not winner :
        printBoard(choices)

        if playerOneTurn :
            print( "Player 1:")
        else :
            print( "Player 2:")

        try:
            choice = int(input(">> "))
        except:
            print("please enter a valid field")
            continue
        if choices[choice - 1] == 'X' or choices [choice-1] == 'O':
            print("illegal move, plase try again")
            continue

        if playerOneTurn :
            choices[choice - 1] = 'X'
            cn=cn+1
        else :
            choices[choice - 1] = 'O'
            cn=cn+1
        playerOneTurn = not playerOneTurn

        for x in range (0, 3) :
            y = x * 3
            if (choices[y] == choices[(y + 1)] and choices[y] == choices[(y + 2)]) :
                winner = True
                printBoard(choices)
            if (choices[x] == choices[(x + 3)] and choices[x] == choices[(x + 6)]) :
                winner = True
                printBoard(choices)

        if((choices[0] == choices[4] and choices[0] == choices[8]) or 
        (choices[2] == choices[4] and choices[4] == choices[6])) :
            winner = True
            printBoard(choices)
        if cn==9 and winner == False:
            print("\n\t..............Draw................")
            IMmodule.mains(uid,upass)

    print ("Player " + str(int(playerOneTurn + 1)) + " wins!\n")


def printBoard(choices) :
    print( '\n\t\t\t -----')
    print( '\t\t\t|' + choices[0] + '|' + choices[1] + '|' + choices[2] + '|')
    print( '\t\t\t -----')
    print( '\t\t\t|' + choices[3] + '|' + choices[4] + '|' + choices[5] + '|')
    print( '\t\t\t -----')
    print( '\t\t\t|' + choices[6] + '|' + choices[7] + '|' + choices[8] + '|')
    print( '\t\t\t -----\n')


    
def Hang(uid,upass):
    #welcoming the user
    name = input("What is your name? ")
    print ("Hello, " + name, "Time to play hangman!")
    print ("\n")
    #wait for 1 second
    time.sleep(1)
    print ("Start guessing...")
    time.sleep(0.5)
    #here we set the secret
    words = ["secret","variable","watermelon","bomber","venila","chocolate","strawberry","counter","ironman","marvel","avengers","legends","amazing","fantastic"]
    i=random.randint(0,len(words)-1)
    word=words[i]
    #creates an variable with an empty value
    guesses = ''
    #determine the number of turns
    turns = 10
    # Create a while loop
    #check if the turns are more than zero
    while turns > 0:         
        # make a counter that starts with zero
        failed = 0             
        # for every character in secret_word    
        for char in word:      
        # see if the character is in the players guess
            if char in guesses:    
            # print then out the character
                print (char,)    
            else:
            # if not found, print a dash
                print ("_",)     
            # and increase the failed counter with one
                failed += 1    
        # if failed is equal to zero
        # print You Won
        if failed == 0:        
            print ("You won")
            print("number of turns left=",turns)
        # exit the script
            break              
        print('\n')
        # ask the user go guess a character
        guess = input("guess a character:") 
        # set the players guess to guesses
        guesses += guess                    
        # if the guess is not found in the secret word
        if guess not in word:  
        # turns counter decreases with 1 (now 9)
            turns -= 1        
        # print wrong
            print ("Wrong")    
        # how many turns are left
            print ("You have", + turns, 'more guesses' )
        # if the turns are equal to zero
            if turns == 0:           
    
            # print "You Loose"
                print ("You Loose")
                IMmodule.mains(uid,upass)
"""def mains(uid1,upass1):
    print("1.Tic Tac Toe('X' and 'O'),")
    print("2.Hangman Game(Guess the word),")
    print("3.Back.")
    uid=uid1
    upass=upass1
    ch=int(input("Enter your choice:-"))
    if ch==1:
        TicTac(uid,upass)
        
    elif ch==2:
        Hang(uid,upass)
        
    elif ch==3:
        IMmodule.login(uid,upass)
"""
