import os
import sales
import database
import sys
import product
import sqlite3
import datetime
now = datetime.datetime.now()

mydb = sqlite3.connect('TEST.db')
mycursor = mydb.cursor()
sq1="CREATE TABLE if not exists BILLING(Billdate DATE, pcode char(30) references product(pcode), pprice float(8,2), pqty int(4), Total double(8,2));"
my1=mycursor.execute(sq1)

for i in my1:
    print (i[0],i[1])
def add_product():
    pcode = input("\t\t\t\t\t -->Enter product code: ")
    sql = "SELECT count(*) from PRODUCTS WHERE pcode="+pcode+";"
    my1=mycursor.execute(sql)
    for x in my1:
        cnt = x[0]
    if cnt != 0 :
        sql = "SELECT * from PRODUCTS WHERE pcode="+pcode+";"
        my2=mycursor.execute(sql)
        for x in my2:
            print("\t\t\t\t\t",x)
            price = int(x[2])
            pqty = int(x[3])
        qty = int(input("\t\t\t\t\t -->Enter no of quantity :"))
        pqty2=pqty-qty
        if qty <= pqty:
            total = qty * price
            now=datetime.datetime.now()
            print("\t\tCollect Rs. ", total)
            sql = "INSERT into SALES values('"+str(now)+"',"+str(pcode)+","+str(price)+","+str(qty)+","+str(total)+");"
            mycursor.execute(sql)
            sq1 = "INSERT into BILLING values('"+str(now)+"',"+str(pcode)+","+str(price)+","+str(qty)+","+str(total)+");"
            mycursor.execute(sq1)
            sql = "UPDATE PRODUCTS SET pqty='"+str(pqty2)+"' WHERE pcode='"+str(pcode)+"';"
            mycursor.execute(sql)
            mydb.commit()
        else:
            print("\t\t\t\t\t Quantity not available")
    else:
        print("\t\t\t\t\t Product is not available")
        return


def check_out():
    sq1="SELECT * from BILLING;"
    my1=mycursor.execute(sq1)
    for i in my1:
        print(i)
    x=int(input("\t\t\t\t1.check out. 2.Back.\n=>Enter your choice:-"))
    if x==1:
        sq1="SELECT SUM(Total) FROM BILLING;"
        my1=mycursor.execute(sq1)
        for i in my1:
            print("\t\tTotal price:-",i[0])
        sq1="DROP TABLE BILLING;"
        my1=mycursor.execute(sq1)
        sq2="CREATE TABLE if not exists BILLING(Billdate DATE, pcode char(30) references product(pcode), pprice float(8,2), pqty int(4), Total double(8,2));"
        my2=mycursor.execute(sq2)
    elif x==2:
        sales.sale_product()
        

def remove_item():
    pcode=str(input("Enter product code:-"))
    sq2="SELECT pqty FROM BILLING WHERE pcode="+pcode+";"
    my2=mycursor.execute(sq2)
    for i in my2:
        qty=i[0]
    sq0="SELECT Billdate FROM BILLING WHERE pcode="+pcode+";"
    my0=mycursor.execute(sq0)
    for i in my0:
        date=i[0]
    sq1="DELETE FROM SALES WHERE pcode='"+str(pcode)+"' AND salesdate='"+str(date)+"';"
    my1=mycursor.execute(sq1)
    sq3="DELETE FROM BILLING WHERE pcode='"+str(pcode)+"';"
    my3=mycursor.execute(sq3)
    sq4 = "UPDATE PRODUCTS SET pqty= pqty+"+str(qty)+" WHERE pcode="+str(pcode)+";"
    mycursor.execute(sq4)
    mydb.commit()


